<?php 

namespace App\Models;



class ClientModel {
	private $_db = null;

	public function __construct($db){
		header('Access-Control-Allow-Origin: *');
		$this->_db = $db;
	}

	public function getPdvs(){
		$users = array();
		$q = $this->_db->query('SELECT pdv.* FROM points pdv');
		while( $user = $q->fetch() ){ 
			$users[] = $user; 
		}
		$q->closeCursor();
		return $users;
	}

	public function getAdresseByPoint($indice_point){
		$q = $this->_db->prepare('SELECT pdv.adresse_point, adminpdv.adresse as adresse_proprietaire FROM points pdv, proprietaires_point adminpdv WHERE pdv.id=:indice_point and pdv.id_proprietaire_point=adminpdv.id limit 1');
		$q->execute(array(':indice_point' => $indice_point));
		$customize = $q->fetch();
		return $customize;
	}
	
	public function getGerants(){
		$users = array();
		$q = $this->_db->query('SELECT g_point.* FROM gerants_point g_point');
		while( $user = $q->fetch() ){ 
			$users[] = $user; 
		}
		$q->closeCursor();
		return $users;
	}

	public function getAdminPdvs(){
		$users = array();
		$q = $this->_db->query('SELECT DISTINCT adminpdv.* FROM points pdv, proprietaires_point adminpdv where pdv.id_proprietaire_point=adminpdv.id');
		while( $user = $q->fetch() ){ 
			$users[] = $user; 
		}
		$q->closeCursor();
		return $users;
	}

    public function existPoint($indice_point){
        $q = $this->_db->prepare('SELECT COUNT(*) FROM points WHERE id=:indice_point or nom_point=:indice_point limit 1');
        $q->execute(array(':indice_point' => $indice_point));
        return array("message" => (bool) $q->fetchColumn());
    }

    public function existPointGerant($nom_point,$telephone_gerant, $nom_gerant){
        $q = $this->_db->prepare('SELECT COUNT(*) FROM points pts, gerants_point g_pts WHERE pts.nom_point=:nom_point and pts.id_gerant_point=g_pts.id and g_pts.telephone=:telephone_gerant and g_pts.nom=:nom_gerant limit 1');
        $q->execute(array(':nom_point' => $nom_point, ':telephone_gerant' => $telephone_gerant, ':nom_gerant' => $nom_gerant));
        return array("message" => (bool) $q->fetchColumn());
    }

    public function getPoint($indice_point){
		$q = $this->_db->prepare('SELECT * FROM points WHERE id=:indice_point or nom_point=:indice_point limit 1');
		$q->execute(array(':indice_point' => $indice_point));
		$customize = $q->fetch();
		return $customize;
	}
	
	public function getPointByIndice($indice_point){
		$q = $this->_db->prepare('SELECT * FROM points pts, gerants_point g_pts, proprietaires_point p_pts WHERE pts.id_gerant_point=g_pts.id and pts.id_proprietaire_point=p_pts.id and (pts.id=:indice_point or pts.nom_point=:indice_point or pts.nom_point=:indice_point) limit 1');
		$q->execute(array(':indice_point' => $indice_point));
		$customize = $q->fetch();
		return $customize;
	}
	
	public function getPointByCommercial($id_commercial){
		$points = array();
        $q = $this->_db->prepare('SELECT 
            pts.*, 
            g_pts.prenom As prenom_gerant, g_pts.nom As nom_gerant, g_pts.email As email_gerant, g_pts.telephone As telephone_gerant, 
            p_pts.prenom As prenom_proprietaire, p_pts.nom As nom_proprietaire, p_pts.telephone As telephone_proprietaire 
            FROM 
            points pts, gerants_point g_pts, proprietaires_point p_pts 
            WHERE 
            pts.id_commercial=:id_commercial and pts.id_gerant_point=g_pts.id and pts.id_proprietaire_point=p_pts.id'
        );
		$q->execute(array(':id_commercial' => $id_commercial));
		while( $point = $q->fetch() ){ 
			$points[] = $point; 
		}
		$q->closeCursor();
		return $points;
	}

	public function getAllDataPoint($indice_point){
		$q = $this->_db->prepare('SELECT pts.*, g_pts.prenom As prenom_gerant, g_pts.nom As nom_gerant, g_pts.email As email_gerant, g_pts.telephone As telephone_gerant, p_pts.prenom As prenom_proprietaire, p_pts.nom As nom_proprietaire, p_pts.telephone As telephone_proprietaire, p_pts.email As email_proprietaire, p_pts.adresse As adresse_proprietaire FROM points pts, gerants_point g_pts, proprietaires_point p_pts WHERE pts.id=:indice_point and pts.id_gerant_point=g_pts.id and pts.id_proprietaire_point=p_pts.id limit 1');
		$q->execute(array(':indice_point' => $indice_point));
		$customize = $q->fetch();
		return $customize;
	}

    public function getPointByRegion($region){
        $points = array();
        $q = $this->_db->query("SELECT pts.id, pts.nom_point, CONCAT(g_pts.prenom,' ', g_pts.nom) AS fullname, g_pts.prenom, g_pts.nom, g_pts.telephone, pts.adresse_point, pts.avis FROM points pts, gerants_point g_pts WHERE pts.id_gerant_point=g_pts.id");
        while( $point = $q->fetch() ){
            if(json_decode($point['adresse_point'])->regionpoint == $region) {
                $points[] = array(
                    'id' => $point['id'],
                    'libellepoint' => $point['nom_point'],
                    'prenom' => $point['prenom'],
                    'nom' => $point['nom'],
                    'fullname' => $point['fullname'],
                    'telephone' => $point['telephone'],
                    'adresse' => json_decode($point['adresse_point'])->adressepoint,
                    'note' => $point['avis']
                );
            }
        }
        $q->closeCursor();
        return $points;
    }

    public function getPointByZone($zone){
        $points = array();
        $q = $this->_db->query("SELECT pts.id, pts.nom_point, CONCAT(g_pts.prenom,' ', g_pts.nom) AS fullname, g_pts.prenom, g_pts.nom, g_pts.telephone, pts.adresse_point, pts.avis FROM points pts, gerants_point g_pts WHERE pts.id_gerant_point=g_pts.id");
        while( $point = $q->fetch() ){
            if(json_decode($point['adresse_point'])->zonepoint == $zone) {
                $points[] = array(
                    'id' => $point['id'],
                    'libellepoint' => $point['nom_point'],
                    'prenom' => $point['prenom'],
                    'nom' => $point['nom'],
                    'fullname' => $point['fullname'],
                    'telephone' => $point['telephone'],
                    'adresse' => json_decode($point['adresse_point'])->adressepoint,
                    'note' => $point['avis']
                );
            }
        }
        $q->closeCursor();
        return $points;
    }

    public function getPointBySouszone($souszone){
        $points = array();
        $q = $this->_db->query("SELECT pts.id, pts.nom_point, CONCAT(g_pts.prenom,' ', g_pts.nom) AS fullname, g_pts.prenom, g_pts.nom, g_pts.telephone, pts.adresse_point, pts.avis FROM points pts, gerants_point g_pts WHERE pts.id_gerant_point=g_pts.id");
        while( $point = $q->fetch() ){
            if(json_decode($point['adresse_point'])->souszonepoint == $souszone) {
                $points[] = array(
                    'id' => $point['id'],
                    'libellepoint' => $point['nom_point'],
                    'prenom' => $point['prenom'],
                    'nom' => $point['nom'],
                    'fullname' => $point['fullname'],
                    'telephone' => $point['telephone'],
                    'adresse' => json_decode($point['adresse_point'])->adressepoint,
                    'note' => $point['avis']
                );
            }
        }
        $q->closeCursor();
        return $points;
    }

    public function insertPoint($nom_point, $adresse_point, $activites, $avis, $id_gerant_point, $id_proprietaire_point, $id_commercial, $services, $fichiers){
        $q = $this->_db->prepare('INSERT INTO points SET nom_point=:nom_point, adresse_point=:adresse_point, activites=:activites, avis=:avis, id_gerant_point=:id_gerant_point, id_proprietaire_point=:id_proprietaire_point, id_commercial=:id_commercial, services=:services, fichiers=:fichiers, date_ajout=NOW() ');
        $q->execute(array(':nom_point' => $nom_point, ':adresse_point' => $adresse_point, ':activites' => $activites, ':avis' => $avis, ':id_gerant_point' => $id_gerant_point, ':id_proprietaire_point' => $id_proprietaire_point, ':id_commercial' => $id_commercial, ':services' => $services, ':fichiers' => $fichiers ));
        return array("message" => $this->_db->lastInsertId());
	}

	public function updatePoint($id, $adresse_point, $services, $activites, $avis, $reponseProspect, $piecesFournies){
//		$etat = $this->existPoint($nom_point);
//		if( $etat['message'] === false) {
			$q = $this->_db->prepare('UPDATE points SET adresse_point=:adresse_point, services=:reponseProspect, fichiers=:piecesFournies, activites=:activites, avis=:avis WHERE id=:id');
			$q->execute(array(':id' => $id, ':adresse_point' => $adresse_point, ':reponseProspect' => $reponseProspect, ':piecesFournies' => $piecesFournies, ':activites' => $activites, ':avis' => $avis));
			return array("message" => $this->_db->lastInsertId());
//		}
//		else{
//			return array("message" => $etat['message']);
//		}
	}

	public function existGerant($indice_gerant){
		$q = $this->_db->prepare('SELECT COUNT(*) FROM gerants_point WHERE id=:indice_gerant or telephone=:indice_gerant or email=:indice_gerant limit 1');
		$q->execute(array(':indice_gerant' => $indice_gerant));
		return array("message" => (bool) $q->fetchColumn());
	}

	public function getGerant($indice_gerant){
		$q = $this->_db->prepare('SELECT * FROM gerants_point WHERE id=:indice_gerant or telephone=:indice_gerant or email=:indice_gerant limit 1');
		$q->execute(array(':indice_gerant' => $indice_gerant));
		$customize = $q->fetch();
		return $customize;
	}

	public function insertGerant($prenom, $nom, $telephone, $email){
		$etat = $this->existGerant($telephone);
		if( $etat['message'] === false) {
			$q = $this->_db->prepare('INSERT INTO gerants_point SET prenom=:prenom, nom=:nom, email=:email, telephone=:telephone, date_ajout=NOW() ');
			$q->execute(array(':prenom' => $prenom, ':nom' => $nom, ':email' => $email, ':telephone' => $telephone));
			return array("message" => $this->_db->lastInsertId());
		}
		else{
			return array("message" => $etat['message']);
		}
	}

	public function updateGerant($id, $prenom, $nom, $telephone, $email){
		$etat = $this->existGerant($telephone);
		if( $etat['message'] === false) {
			$q = $this->_db->prepare('UPDATE gerants_point SET prenom=:prenom, nom=:nom, email=:email, telephone=:telephone WHERE id=:id ');
			$q->execute(array(':id' => $id, ':prenom' => $prenom, ':nom' => $nom, ':email' => $email, ':telephone' => $telephone));
			return array("message" => $this->_db->lastInsertId());
		}
		else{
			return array("message" => $etat['message']);
		}
	}

	public function existProprietaire($indice_proprietaire){
		$q = $this->_db->prepare('SELECT COUNT(*) FROM proprietaires_point WHERE id=:indice_proprietaire or telephone=:indice_proprietaire or email=:indice_proprietaire limit 1');
		$q->execute(array(':indice_proprietaire' => $indice_proprietaire));
		return array("message" => (bool) $q->fetchColumn());
	}

	public function getProprietaire($indice_proprietaire){
		$q = $this->_db->prepare('SELECT * FROM proprietaires_point WHERE id=:indice_proprietaire or telephone=:indice_proprietaire or email=:indice_proprietaire limit 1');
		$q->execute(array(':indice_proprietaire' => $indice_proprietaire));
		$customize = $q->fetch();
		return $customize;
	}

	public function insertProprietaire($prenom, $nom, $telephone, $email, $adresse){
		$etat = $this->existProprietaire($telephone);
		if( $etat['message'] === false) {
			$q = $this->_db->prepare('INSERT INTO proprietaires_point SET prenom=:prenom, nom=:nom, email=:email, telephone=:telephone, adresse=:adresse, date_ajout=NOW() ');
			$q->execute( array(':prenom' => $prenom, ':nom' => $nom, ':email' => $email, ':telephone' => $telephone, ':adresse' => $adresse) );
			return array("message" => $this->_db->lastInsertId());
		}
		else{
			return array("message" => $etat['message']);
		}
	}

	public function updateProprietaire($id, $prenom, $nom, $telephone, $email, $adresse){
		$etat = $this->existProprietaire($telephone);
		if( $etat['message'] === false) {
			$q = $this->_db->prepare('UPDATE proprietaires_point SET prenom=:prenom, nom=:nom, email=:email, telephone=:telephone, adresse=:adresse WHERE id=:id');
			$q->execute( array(':id' => $id, ':prenom' => $prenom, ':nom' => $nom, ':email' => $email, ':telephone' => $telephone, ':adresse' => $adresse) );
			return array("message" => $this->_db->lastInsertId());
		}
		else{
			return array("message" => $etat['message']);
		}
	}
	public function getProspects($token){
		$req1=$this->_db->prepare('SELECT * FROM users WHERE token=:t');
		$req1->execute(array('t'=>$token));
		$id=$req1->fetch();
		if($id['id_user']!=null){
		     $req=$this->_db->prepare('SELECT * FROM suivis WHERE qualification=:q AND id_superviseur=:idsup');
		     $req->execute(array('q'=>'valider','idsup'=>$id['id_user']));
		     $pro=array();
		     //$pro=$req->fetchAll();
		     while($tup=$req->fetch()){
			     $pro[]=$tup;
			  }
		return $pro;
	   }
	   return null;
    }
	public function getclient($token){
		$req1=$this->_db->prepare('SELECT * FROM users WHERE token=:t');
		$req1->execute(array('t'=>$token));
		$id=$req1->fetch();
		if($id['id_user']!=null){
		     
		     $req=$this->_db->prepare('SELECT * FROM points WHERE id_commercial IN (SELECT id_user FROM users WHERE depends_on=:idcc)');
		     $req->execute(array('idcc'=>$id['id_user']));
		     
		     $pro=array();
		     while($tup=$req->fetch()){
			    //$pro[]=$tup;
			     $gerant=$this->_db->prepare('SELECT * FROM gerants_point WHERE id=?');
			     $gerant->execute(array($tup['id_gerant_point']));
			     $ger=$gerant->fetch();
			     
			    /* $com=$this->_db->prepare('SELECT * FROM users_ WHERE id_user=?');
			     $com->execute(array($tup['id_commercial']));
			     $comm=$com->fetch();*/
			     $pro[]=array('nom_point'=>$tup['nom_point'],'adresse'=>$tup['adresse_point'],'gerant'=>$ger['prenom'],'tel'=>$ger['telephone']);
			  }
		return $pro;
	   }
	   return null;
    }

}
