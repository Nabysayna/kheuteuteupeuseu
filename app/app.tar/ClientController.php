<?php 
    

namespace App\Controllers;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;

use \App\Controller;

//use \App\Controllers\SmsService;

use \App\Models\UserModel;
use \App\Models\ClientModel;
use \App\Models\AuthModel;
use \App\Models\AssignationModel;
use \App\Models\SuiviModel;


class ClientController extends Controller {
  // private $smsSender = new SmsService() ;

    public function getPointByRegion(Request $request, Response $response, $args){
        header("Access-Control-Allow-Origin: *");
        $data = $request->getParsedBody();
        $params = json_decode($data['params']);

        $userModel = new ClientModel($this->db);
        $getUsers = $userModel->getPointByRegion($params->region);
        return $response->withJson($getUsers);
    }

    public function getPointByZone(Request $request, Response $response, $args){
       header("Access-Control-Allow-Origin: *");
        $data = $request->getParsedBody();
        $params = json_decode($data['params']);

        $userModel = new ClientModel($this->db);
        $getUsers = $userModel->getPointByZone($params->zone);
        return $response->withJson($getUsers);
    }

    public function getPointBySouszone(Request $request, Response $response, $args){
        header("Access-Control-Allow-Origin: *");
        $data = $request->getParsedBody();
        $params = json_decode($data['params']);

        $userModel = new ClientModel($this->db);
        $getUsers = $userModel->getPointBySouszone($params->souszone);
        return $response->withJson($getUsers);
    }
    public function getProspects(Request $request, Response $response,$args){
		header("Access-Control-Allow-Origin: *");
		
		$data = $request->getParsedBody();
        $params = json_decode($data['param']);
		$pros=new ClientModel($this->db);
		$prospects=$pros->getProspects($params->token);
		return $response->withJson($prospects);
	}
    public function getclient(Request $request, Response $response,$args){
		header("Access-Control-Allow-Origin: *");
		
		$data = $request->getParsedBody();
        $params = json_decode($data['param']);
		$pros=new ClientModel($this->db);
		$prospects=$pros->getclient($params->token);
		return $response->withJson($prospects);
	}

    public function getPointByCommercial(Request $request, Response $response, $args){
      header("Access-Control-Allow-Origin: *");
      
      $data = $request->getParsedBody();
      $params = json_decode($data['params']);

      $authModel = new AuthModel($this->db);
      $auth = $authModel->isUser($params->token);
      if($auth['message']){
        $clientModel = new ClientModel($this->db);
        $getUsers = $clientModel->getPointByCommercial($auth['message']['id_user']);
        return $response->withJson(array('errorCode' => true, "message" => $getUsers));
      }
      else{
        return $response->withJson(array('errorCode' => false, "message" => "dejaenregistrer2"));
      }
    }
    
    public function getPdvs(Request $request, Response $response, $args){
      header("Access-Control-Allow-Origin: *");
      
        $userModel = new ClientModel($this->db);
        $getUsers = $userModel->getPdvs();
        return $response->withJson($getUsers);
    }
    
    public function getAdresseByPoint(Request $request, Response $response, $args){
      header("Access-Control-Allow-Origin: *");
      
      $data = $request->getParsedBody();
      $params = json_decode($data['params']);

      $userModel = new ClientModel($this->db);
      $getUsers = $userModel->getAdresseByPoint($params);
      return $response->withJson($getUsers);
    }
    
    public function getAllDataPoint(Request $request, Response $response, $args){
      header("Access-Control-Allow-Origin: *");
      $data = $request->getParsedBody();
      $params = json_decode($data['params']);

      $userModel = new ClientModel($this->db);
      $getUsers = $userModel->getAllDataPoint($params);
      return $response->withJson($getUsers);
    }
    
    
  
  public function getGerants(Request $request, Response $response, $args){
      header("Access-Control-Allow-Origin: *");
      
        $userModel = new ClientModel($this->db);
        $getUsers = $userModel->getGerants();
        return $response->withJson($getUsers);
    }
    
    public function getAdminPdvs(Request $request, Response $response, $args){
  		header("Access-Control-Allow-Origin: *");
      
      	$userModel = new ClientModel($this->db);
      	$getUsers = $userModel->getAdminPdvs();
      	return $response->withJson($getUsers);
    }

    public function insertPoint(Request $request, Response $response, $args){
      header("Access-Control-Allow-Origin: *");
      $data = $request->getParsedBody();
      $params = json_decode($data['params']);

      $userModel = new UserModel($this->db);
      $clientModel = new ClientModel($this->db);

        $assignModel = new AssignationModel($this->db);
        $suiviModel = new SuiviModel($this->db);
        $userModel = new UserModel($this->db);

        $id_commercial = 0;

      $authModel = new AuthModel($this->db);
      $auth = $authModel->isUser($params->token);
      if($auth['message']){
        $id_commercial = $auth['message']['id_user'];
      }
      if(!$auth['message']){
        return $response->withJson(array('errorCode' => false));
      }

      $id_gerant_point = 0; 
      $id_proprietaire_point = 0;
      $params = $params->data;
      if( !empty($params->nompoint) && !empty($params->telephonegerant) && !empty($params->telephoneproprietaire) ){
        $estpoint = $clientModel->existPointGerant($params->nompoint, $params->telephonegerant, $params->nomgerant)['message'];
        if( $estpoint === false) {
          $gerant_point = $clientModel->getGerant($params->telephonegerant);
          if( $gerant_point === false) {
            $id_gerant_point = $clientModel->insertGerant($params->prenomgerant, $params->nomgerant, $params->telephonegerant, $params->emailgerant)['message'];
          }
          if($gerant_point) { $id_gerant_point = $gerant_point['id']; }
          $proprietaire_point = $clientModel->getProprietaire($params->telephoneproprietaire);
          if( $proprietaire_point === false) {
            $id_proprietaire_point = $clientModel->insertProprietaire(
              $params->prenomproprietaire,
              $params->nomproprietaire,
              $params->telephoneproprietaire,
              $params->emailproprietaire,
              json_encode($params->adressecompletproprietaire)
              )['message'];
          }
          if($proprietaire_point) {
            $id_proprietaire_point = $proprietaire_point['id'];
          }

          $respPoint = $clientModel->insertPoint($params->nompoint, json_encode($params->adressecompletpoint), json_encode($params->typeactivite), $params->avissurpoint, $id_gerant_point, $id_proprietaire_point, $id_commercial, json_encode($params->reponsesProspect), json_encode($params->piecesFournies) );


          $id_assigner = -1*$respPoint['message'];
          $ids_assigner = array($id_assigner."");
          $respCommercial = $assignModel->objectifassignation($params->adressecompletpoint->regionpoint,
              $params->adressecompletpoint->zonepoint, $params->adressecompletpoint->souszonepoint,
              $id_commercial, json_encode($ids_assigner), 1, "commercial"
          );
          $respSuperviseur = $assignModel->objectifassignation($params->adressecompletpoint->regionpoint,
              $params->adressecompletpoint->zonepoint, $params->adressecompletpoint->souszonepoint,
              $auth['message']['depends_on'], json_encode($ids_assigner), 1, "superviseur"
          );

          $client = array("id" => $respPoint['message'], "libellepoint" => $params->nompoint, "nom_point" => $params->nompoint,
              "prenom" => $params->prenomgerant, "prenom_gerant" => $params->nomgerant, "nom" => $params->nomgerant,
              "nom_gerant" => $params->nomgerant, "fullname" => $params->prenomgerant.' '.$params->nomgerant,
              "telephone" => $params->telephonegerant, "telephone_gerant" => $params->telephonegerant,
              "adresse_point" => json_encode($params->adressecompletpoint),
              "adresse" => json_encode($params->adressecompletpoint), "note" => $params->avissurpoint, "commentaire" => ''
          );
          $commercial = $userModel->getUser($id_commercial)['message'];
          $superviseur = $userModel->getUser($auth['message']['depends_on'])['message'];
          $infosup = array(
              "date_assignationsuperviser" => date("Y-m-d H:i:s"),
              "objectifsuperviseur" => 1,
              "commentaireforsuperviseur" => "",
              "date_assignationcommercial" => date("Y-m-d H:i:s"),
              "objectifcommercial" => 1,
              "commentaireforcommercial" => ""
          );
          $dates_suivi = array("dateniveau1" => date("Y-m-d H:i:s"), "dateniveau2" => "", "dateniveau3" => "");

          $respSuivi = $suiviModel->ajoutsuivifromprospect(
            json_encode($dates_suivi),
            $respPoint['message'],
            $id_commercial,
            $auth['message']['depends_on'],
            json_encode($client),
            json_encode($commercial),
            json_encode($superviseur),
            $params->avissurpoint,
            json_encode($infosup),
            $id_assigner,
            json_encode($params->reponsesProspect)
          );

        return $response->withJson(array('errorCode' => 'true', "message" => $respSuivi));
       // return $response->write(intval(1));
        }
        else{
          return $response->withJson(array('errorCode' => 'false', "message" => "deja enregistrer"));
         // return $response->write(intval(2));
        }
      }
      else{
        return $response->withJson(array('errorCode' => 'false', "message" => "donnees manquantes"));
        //return $response->write(intval(3));

         // return $response->withJson(array('errorCode' => false, "message" => "dejaenregistrer"));
        }
      }
      
      
    
}

